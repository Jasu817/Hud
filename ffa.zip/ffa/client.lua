local kills = 0
local deaths = 0
local istInDimension = false
local hasRun = false
local isDead = false
local areenalla = false

CreateThread(function()
    local model = GetHashKey('s_m_m_movspace_01')
    RequestModel(model)
    while not HasModelLoaded(model) do
        Wait(1)
    end


    local ped = CreatePed(0, model, 149.91, -980.34, 29.09, 267.47)
    FreezeEntityPosition(ped, true)
    SetEntityInvincible(ped, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    TaskStartScenarioInPlace(ped, "WORLD_HUMAN_AA_SMOKE", 0, true)

    exports.ox_target:addSphereZone({
        coords = vec3(149.91, -980.34, 29.09 + 1.0),
        radius = 1,
        distance = 1.0,
        debug = false,
        options = {
            {
                type = "ped",
                name = "FFA",
                icon = "fas fa-shop",
                label = "FFA",
                onSelect = function()
                    OpenMenu()
                end
            },
        }
    })
end)

RegisterCommand("poistuffa", function()
    if istInDimension and not isDead then
        CreateThread(function(dimension)
            local dimension = Config.Teleports.standart.dimension
            SetEntityCoords(GetPlayerPed(-1), vector3(150.95, -981.03, 29.09), false, false, false, false)
            lib.hideTextUI()
            TriggerServerEvent('dimension', dimension)
            TriggerServerEvent('Save:info', kills, deaths)
            TriggerEvent('removeloadout')
            TriggerServerEvent('removein')
            NetworkSetFriendlyFireOption(true)
            SetCanAttackFriendly(GetPlayerPed(-1), true, true)
            drinnen = false
            exports['pma-voice']:removePlayerFromRadio()
            TriggerEvent('esx:restoreLoadout')
        end)
    end
end, false)


CreateThread(function()
    Wait(2500)
    ESX.TriggerServerCallback('getInfo', function(info)
        if info[1].kills ~= nil then
            kills = info[1].kills
            deaths = info[1].deaths
        end
    end)
end)

RegisterNetEvent("addKill", function()
    kills = kills + 1
end)

RegisterNetEvent("addDeath", function()
    deaths = deaths + 1
end)

function TPGrapeseed()
    local spawnpoints = Config.Teleports.Grapeseed.spawnpoints
    local coords = spawnpoints[math.random(#spawnpoints)]
    local dimension = Config.Teleports.Grapeseed.dimension
    SetEntityCoords(cache.ped, coords, false, false, false, false)
    TriggerServerEvent('dimension', dimension)
    TriggerEvent('loadout')
    ClearAreaOfPeds(coords, 5000, true)
    exports['pma-voice']:addPlayerToRadio(55.54)
end

function TPVankila()
    local spawnpoints = Config.Teleports.Vankila.spawnpoints
    local coords = spawnpoints[math.random(#spawnpoints)]
    local dimension = Config.Teleports.Vankila.dimension
    SetEntityCoords(cache.ped, coords, false, false, false, false)
    TriggerServerEvent('dimension', dimension)
    TriggerEvent('loadout')
    ClearAreaOfPeds(coords, 5000, true)
    exports['pma-voice']:addPlayerToRadio(55.53)
end

function TPRomuttamo()
    local spawnpoints = Config.Teleports.Romuttamo.spawnpoints
    local coords = spawnpoints[math.random(#spawnpoints)]
    local dimension = Config.Teleports.Romuttamo.dimension
    SetEntityCoords(cache.ped, coords, false, false, false, false)
    TriggerServerEvent('dimension', dimension)
    TriggerEvent('loadout')
    ClearAreaOfPeds(coords, 5000, true)
    exports['pma-voice']:addPlayerToRadio(55.52)
end

--[[function TP1V1()
    local spawnpoints = Config.Teleports.yksvsyks.spawnpoints
    local coords = spawnpoints[math.random(#spawnpoints)]
    local dimension = Config.Teleports.yksvsyks.dimension
    SetEntityCoords(cache.ped, coords, false, false, false, false)
    TriggerServerEvent('dimension', dimension)
    TriggerEvent('loadout')
    ClearAreaOfPeds(coords, 5000, true)
    exports['pma-voice']:addPlayerToRadio(55.58)
end--]]

function OpenMenu()
    local elements = {}
    ESX.TriggerServerCallback('OtaInfo', function(count)
        local h = count.h
        local m = count.m
        local l = count.l
        local o = count.o


        table.insert(elements, {
            title = "GrapeSeed",
            description = "Pelaajat: " .. m .. "/20",
            arrow = true,
            icon = 'fas fa-wifi',
            iconAnimation = "beat",
            onSelect = function()
                if count.m < 20 then
                    RemoveAllPedWeapons(cache.ped, true)
                    TriggerServerEvent('insertin')
                    TPGrapeseed()
                    DisplayPoints()
                elseif count.m >= 20 then
                    lib.notify { title = 'FFA', description = 'Tässä FFA-areenassa on jo 20 henkilöä', duration = 10000 }
                end
            end,
        })

        table.insert(elements, {
            title = "Romuttamo",
            description = "Pelaajat: " .. l .. "/20",
            arrow = true,
            icon = 'fas fa-wifi',
            iconAnimation = "fade",
            onSelect = function()
                if count.l < 20 then
                    RemoveAllPedWeapons(cache.ped, true)
                    TriggerServerEvent('insertin')
                    TPRomuttamo()
                    DisplayPoints()
                elseif count.l >= 20 then
                    lib.notify { title = 'FFA', description = 'Tässä FFA-areenassa on jo 20 henkilöä', duration = 10000 }
                end
            end,
        })

        table.insert(elements, {
            title = "Vankila",
            description = "Pelaajat: " .. h .. "/20",
            arrow = true,
            icon = 'fas fa-wifi',
            iconAnimation = "fade",
            onSelect = function()
                if count.h < 20 then
                    RemoveAllPedWeapons(cache.ped, true)
                    TriggerServerEvent('insertin')
                    TPVankila()
                    DisplayPoints()
                elseif count.h >= 20 then
                    lib.notify { title = 'FFA', description = 'Tässä FFA-areenassa on jo 20 henkilöä', duration = 10000 }
                end
            end,
        })
            
            --[[table.insert(elements, {
                title = "1v1",
                description = "Pelaajat: " ..o.. "/2",
                arrow = true,
                icon = 'fas fa-wifi',
                iconAnimation = "fade",
                onSelect = function()
                    if count.o < 2 then
                        RemoveAllPedWeapons(cache.ped, true)
                        TriggerServerEvent('insertin')
                        TP1V1()
                        DisplayPoints()
                    elseif count.o >= 2 then
                        lib.notify { title = 'FFA', description = 'Tässä FFA-areenassa on jo 2 henkilöä', duration = 10000 }
                    end
                end,
            })--]]

        lib.registerContext({
            id = 'ffa_main_menu',
            title = "FFA Valikko",
            options = elements
        })

        lib.showContext('ffa_main_menu')
    end)
end

RegisterNetEvent('kuolema:show', function(killerName, sourceName)
    if istInDimension then
        lib.notify({
            title = 'FFA',
            description = killerName .. " Tappoi " .. sourceName,
            position = "top-right",
            duration = 4000,
            icon = 'gun',
            iconColor = '#0000FF',
        })
    end
end)

AddEventHandler('esx:onPlayerDeath', function(data)
    if istInDimension then
        local killerServerId = data.killerServerId
        local playerPed = PlayerPedId()
        local killerPed = GetPlayerPed(GetPlayerFromServerId(killerServerId))

        if killerPed ~= playerPed and DoesEntityExist(killerPed) then
            TriggerServerEvent('killed', killerServerId)
        end

        Wait(1000)

        for _, v in pairs(Config.Teleports) do
            if GetDistanceBetweenCoords(v.spawnpoints[1], GetEntityCoords(playerPed), true) <= 200.0 then
                local coords = v.spawnpoints[math.random(#v.spawnpoints)]
                SetEntityCoords(playerPed, coords, false, false, false, false) 
            end
        end

        TriggerEvent('esx_ambulancejob:revive')
        Wait(1000)
        AddArmourToPed(playerPed, 200)
        SetEntityHealth(playerPed, 200)
        SetPedArmour(playerPed, 200)
        NetworkSetFriendlyFireOption(false)
        SetCanAttackFriendly(playerPed, false, false)
        Wait(3000)
        NetworkSetFriendlyFireOption(true)
        SetCanAttackFriendly(playerPed, true, true)
        AddAmmoToPed(playerPed, -1075685676, 700)
        AddAmmoToPed(playerPed, 137902532, 700)
    end
end)

local blips = {
    {title="FFA", scale=0.6, colour=1, id=150, x = 150.95, y = -981.03, z = 29.09}
 }

CreateThread(function(name)
    for _, info in pairs(blips) do
        info.blip = AddBlipForCoord(info.x, info.y, info.z)
        SetBlipSprite(info.blip, info.id)
        SetBlipDisplay(info.blip, 4)
        SetBlipScale(info.blip, 0.6)
        SetBlipColour(info.blip, info.colour)
        SetBlipAsShortRange(info.blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(info.title)
        EndTextCommandSetBlipName(info.blip)
    end
end)

local firstspawn = true
AddEventHandler('playerSpawned', function(spawn)
    if not firstspawn then
        firstspawn = true
        while GetEntityModel(cache.ped) ~= 1885233650 do
            Wait(200)
        end
        ESX.TriggerServerCallback('isIn', function(bool)
            if bool then
                RemoveAllPedWeapons(cache.ped, false)
                TriggerServerEvent('removein')
                SetEntityCoords(cache.ped, vector3(150.95, -981.03, 29.09), false, false, false, false)
            end
        end)
    end
end)

RegisterNetEvent('heal', function ()
    SetPedArmour(cache.ped, 200)
    SetEntityHealth(cache.ped, 200)
end)

function onEnter(zoneIndex, zoneData)
    if not istInDimension then return end
    if not areenalla then
        areenalla = true
        if not istInDimension then
            TriggerEvent('loadout')
            istInDimension = true
        end
    end
end

function onExit(zoneIndex, zoneData)
    if not istInDimension then return end
    if areenalla then
        areenalla = false
        if istInDimension then
            hasRun = true
            Wait(44)
            SetEntityHealth(cache.ped, 0)
            lib.notify{title = 'FFA', description = 'Olet poistunut alueelta!', duration = 10000}
        end
    end
end

CreateThread(function()
    local zones = {
        {x = 1655.7466, y = 2526.3701, z = 45.5596, Radius = 130.0},
        {x = 2356.2009, y = 3081.5596, z = 48.1880, Radius = 115.0},
        {x = 69.2822, y = 3681.6162, z = 39.7286, Radius = 120.0},
        {x = 103.0303, y = -871.6068, z = 135.8178, Radius = 50.0},
    }

    for zoneIndex, zoneData in ipairs(zones) do
        lib.zones.sphere({
            coords = vector3(zoneData.x, zoneData.y, zoneData.z),
            radius = zoneData.Radius or 100.0,
            debug = false,
            onEnter = function() onEnter(zoneIndex, zoneData) end,
            onExit = function() onExit(zoneIndex, zoneData) end,
        })
    end

    while true do
        Wait(1000)
        if areenalla then
            for _, player in ipairs(GetActivePlayers()) do
                if IsPedInAnyVehicle(GetPlayerPed(player), true) then
                    local veh = GetVehiclePedIsUsing(GetPlayerPed(player))
                    SetEntityNoCollisionEntity(cache.ped, veh, true)
                end
            end
            hasRun = false
        end
    end
end)

RegisterNetEvent('loadout', function()
    SetEntityHealth(cache.ped, 200)
    SetPedArmour(cache.ped, 200)
    GiveWeaponToPed(cache.ped, -1075685676, 700, 0, 0)
    GiveWeaponToPed(cache.ped, 137902532, 700, 0, 0)
    GiveWeaponComponentToPed(cache.ped, -1075685676, 0x65EA7EBB)
    GiveWeaponComponentToPed(cache.ped, 137902532, 0xC304849A)
    lib.notify { title = 'FFA', description = 'Olet saapunut FFA-alueelle, komennolla /poistuffa voit poistua alueelta', duration = 10000 }
    istInDimension = true
end)

RegisterNetEvent('removeloadout', function()
    SetEntityHealth(cache.ped, 200)
    SetPedArmour(cache.ped, 0)
    RemoveWeaponFromPed(cache.ped, -1075685676)
    RemoveWeaponFromPed(cache.ped, 137902532)
    lib.notify { title = 'FFA', description = 'Olet poistunut FFA-alueelta', duration = 10000 }
    TriggerServerEvent('removein')
    istInDimension = false
end)

function DisplayPoints()
    local drinnen = true
    while true do
        Wait(0)
        if drinnen then
            local kd
            if deaths > 0 then
                kd = ESX.Math.Round(kills / deaths, 2)
            else
                kd = kills
            end
            
            local text = {('Tapot: ' .. kills .. ' \n Kuolemat: ' .. deaths .. ' \n KD: ' .. kd .. ' \n /poistuffa Päästäksesi ulos')}
            lib.showTextUI(table.concat(text))
        end
    end
end

AddEventHandler('onResourceStop', function(resource)
    if resource == GetCurrentResourceName() then
        if istInDimension then
            TriggerServerEvent('dimension', 0)
            TriggerServerEvent('Save:info', kills, deaths)
            TriggerEvent('removeloadout')
            TriggerServerEvent('removein')
            SetEntityCoords(PlayerPedId(), 150.95, -981.03, 29.09, false, false, false, false)
            istInDimension = false
            lib.hideTextUI()
            lib.notify{title = 'FFA', description = 'Scripti ressutettiin, jotenka sinut bringattiin alkuun', type = 'success', duration = 10000}
            TriggerEvent('esx:restoreLoadout')
        end
    end
end)