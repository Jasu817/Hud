local moiner = {}

AddEventHandler("playerDropped", function()
    local source = source
    if moiner[source] then
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer then
            xPlayer.removeWeapon('WEAPON_PISTOL_MK2')
            xPlayer.removeWeapon('WEAPON_VINTAGEPISTOL')

            MySQL.Async.execute('DELETE FROM ffa_in WHERE identifier = @identifier', {
                ['@identifier'] = xPlayer.identifier
            }, function(affectedRows)
                if affectedRows then
                    print("Pelaaja poistettiin ffa_in tablesta!")
                else
                    print('ERROR!!')
                end
            end)
        end
    end
end)

RegisterServerEvent('dimension', function(dimension)
    SetPlayerRoutingBucket(source, dimension)
    if dimension > 0 then
        moiner[source] = true
    else
        moiner[source] = false
    end
end)

RegisterServerEvent('killed', function(killerServerId)
    local victim = source
    local xSource = ESX.GetPlayerFromId(victim)

    if killerServerId ~= nil and xSource then
        local xPlayer = ESX.GetPlayerFromId(killerServerId)

        if xPlayer then
            local killerName = GetPlayerName(killerServerId)
            local victimName = GetPlayerName(victim)

            if killerName and victimName then
                for player, _ in pairs(moiner) do
                    TriggerClientEvent('kuolema:show', player, killerName, victimName)
                end

                TriggerClientEvent('heal', killerServerId)
                TriggerClientEvent('addKill', killerServerId)
            end
        end
    else
        print("ERROR! NIL in killerServerId or xSource")
    end

    if xSource then
        xSource.triggerEvent('addDeath')
    else
        print("ERROR! NIL in xSource")
    end
end)


ESX.RegisterServerCallback('OtaInfo', function(source, cb)
        local pelaajat = {
            h = 0,
            m = 0,
            l = 0,
            o = 0,
        }

        local players = ESX.GetPlayers()
        for i = 1, #players do
            if GetPlayerRoutingBucket(players[i]) == 30 then
                pelaajat.h = pelaajat.h + 1
            elseif GetPlayerRoutingBucket(players[i]) == 32 then
                pelaajat.m = pelaajat.m + 1
            elseif GetPlayerRoutingBucket(players[i]) == 33 then
                pelaajat.l = pelaajat.l + 1
            elseif GetPlayerRoutingBucket(players[i]) == 34 then
                pelaajat.o = pelaajat.o + 1
        end
    end
    cb(pelaajat)
end)

ESX.RegisterServerCallback('getInfo', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local info = {}
    MySQL.Async.fetchAll('SELECT * FROM ffa WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(data)
        if data[1] ~= nil then
            if data[1].kills ~= nil then
                table.insert(info, { kills = data[1].kills, deaths = data[1].deaths })
                cb(info)
            end
        end
    end)
end)

ESX.RegisterServerCallback('isIn', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.fetchAll('SELECT * FROM ffa_in WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(data)
        if data[1] ~= nil then
            if data[1].identifier ~= nil then
                cb(true)
            end
        end
    end)
end)

RegisterServerEvent('removein', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer then
        MySQL.Async.execute('DELETE FROM ffa_in WHERE identifier = @identifier', {
            ['@identifier'] = xPlayer.identifier
        }, function(affectedRows)
            if affectedRows and affectedRows > 0 then
                print("Pelaajan data poistettiin databasesta: ffa_in!!!")
            else
                print("ERROR POISTOSSA!")
            end
        end)
    else
        print("Player not found.")
    end
end)

RegisterServerEvent('insertin', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer then
        MySQL.Async.execute('INSERT INTO ffa_in (identifier) VALUES (@identifier)', {
            ['@identifier'] = xPlayer.identifier
        }, function(rowsChanged)
            if rowsChanged and rowsChanged > 0 then
                print("Pelaajan data insertattiin databaseen: ffa_in!!!")
            else
                print("ERROR INSERTISSÄ!")
            end
        end)
    else
        print("Player not found")
    end
end)


RegisterServerEvent('Save:info', function(tapot, kuolemat)
    local deaths = kuolemat
    local kills = tapot
    local xPlayer = ESX.GetPlayerFromId(source)

    MySQL.Async.fetchAll('SELECT * FROM ffa WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(data)
        if data[1] ~= nil then
            MySQL.Async.execute('UPDATE ffa SET kills = @kills, deaths = @deaths WHERE identifier = @identifier', {
                ['@identifier'] = xPlayer.getIdentifier(),
                ['@kills'] = kills,
                ['@deaths'] = deaths
            }, function(rowsChanged)
            end)
        elseif data[1] == nil then
            MySQL.Async.execute('INSERT INTO ffa  (identifier, kills, deaths) VALUES (@identifier, @kills, @deaths)',
                {
                    ['@identifier'] = xPlayer.identifier,
                    ['@kills']      = kills,
                    ['@deaths']     = deaths
                }, function(rowsChanged)

                end)
        end
    end)
end)
