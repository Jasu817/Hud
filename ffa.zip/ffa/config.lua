Config = {}

Config.Teleports = {
  standart = {
      dimension = 0,
      spawnpoints = {
          vector3(149.91, -980.34, 30.09),
      },
  },
  ["Vankila"] = {
      dimension = 30,
      spawnpoints = {
          vector3(1629.33, 2496.81, 44.56),
          vector3(1622.69, 2561.02, 44.56),
          vector3(1762.322, 2542.14, 44.56),
          vector3(1723.89, 2494.1, 45.56),
          vector3(1692.69, 2471.34, 45.57),
          vector3(1619.16, 2570.29, 45.56),
          vector3(1758.79, 2518.91, 45.56),
          vector3(1616.79, 2524.93, 44.56),
      },
  },
  ["Romuttamo"] = {
      dimension = 33,
      spawnpoints = {
          vector3(2409.35, 3034.52, 48.21),
          vector3(2361.51, 3132.52, 48.21),
          vector3(2420.44, 3154.43, 48.21),
          vector3(2423.35, 3112.52, 48.21),
          vector3(2352.51, 3063.52, 48.21),
          vector3(2427.44, 3082.43, 48.21),
      },
  },
  ["Grapeseed"] = {
      dimension = 32,
      spawnpoints = {
          vector3(99.7, 3578.83, 38.67),
          vector3(92.87, 3652.0, 38.56),
          vector3(-14.02, 3723.31, 38.99),
          vector3(11.22, 3663.51, 39.56),
          vector3(81.22, 3746.51, 38.56),
          vector3(107.22, 3695.51, 38.56),
          vector3(33.22, 3665.51, 38.56),
      },
  },
}
  --[["yksvsyks"] = {
    dimension = 34,
    spawnpoints = {
        vector3(118.6158, -877.6031, 134.7700),
        vector3(84.0135, -865.2577, 134.7700),
    },
},--]]